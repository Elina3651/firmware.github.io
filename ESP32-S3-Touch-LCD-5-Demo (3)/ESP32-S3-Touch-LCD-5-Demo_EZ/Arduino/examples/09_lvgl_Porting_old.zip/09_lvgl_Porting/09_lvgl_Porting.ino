#include <Arduino.h>
#include <esp_display_panel.hpp> // Для дисплея, тача, платы
#include <lvgl.h>
#include "lvgl_v8_port.h"      // Порт LVGL для esp-display-panel
#include "waveshare_sd_card.h" // Твои функции для SD: listDir, writeFile и т.д.
#include <SD.h>
#include <SPI.h>
#include <vector>
#include <string.h> // Для strdup, memset, strncpy, strcat, strlen

// Используем пространства имен для краткости
using namespace esp_panel::drivers;
using namespace esp_panel::board;

// --- Глобальные объекты и переменные ---
Board* board = nullptr;
esp_expander::CH422G* ch422g = nullptr;
bool sd_card_initialized = false;
int current_profile_next_id = 1;

// Экраны LVGL
lv_obj_t * screen_main_app = nullptr;
lv_obj_t * screen_profile_details = nullptr;

// Объекты для главного экрана (screen_main_app)
lv_obj_t * list_profiles_main;
lv_obj_t * ta_profile_input_main;
lv_obj_t * kb_main_ui;
lv_obj_t * label_status_msg_main;

// Объекты для экрана деталей профиля (screen_profile_details)
lv_obj_t * label_detail_profile_name;
lv_obj_t * label_detail_profile_content;

// Буфер и имя активного профиля
#define FILE_CONTENT_BUFFER_SIZE 256
char file_content_buffer[FILE_CONTENT_BUFFER_SIZE];
char active_profile_name_for_start[64];

// --- Вспомогательная функция для критических ошибок ---
void handleFatalError(const char* message) {
    Serial.println("-------------------- FATAL ERROR --------------------");
    Serial.println(message);
    Serial.println("System halted.");
    Serial.println("-----------------------------------------------------");
    while (1) { delay(1000); }
}

// --- Функция для чтения файла в char буфер (в .ino) ---
bool readFileContentToBuffer_ino(fs::FS &fs_ref, const char * path, char* buffer, size_t buffer_size) {
    Serial.printf("INO: Reading file to char buffer: %s (buffer_size: %u)\n", path, buffer_size);
    if (buffer_size == 0) { Serial.println("INO: readFileContentToBuffer_ino - Zero buffer size!"); return false; }
    memset(buffer, 0, buffer_size); 
    if (!sd_card_initialized) { Serial.println("INO: readFileContentToBuffer_ino - SD card not initialized!"); strncpy(buffer, "(SD Error: Not Init)", buffer_size - 1); return false; }
    File file = fs_ref.open(path, FILE_READ);
    if (!file) { Serial.printf("INO: Failed to open file for reading: %s\n", path); strncpy(buffer, "(File Open Error)", buffer_size - 1); return false; }
    size_t file_actual_size = file.size();
    size_t bytes_to_read = (file_actual_size < buffer_size -1) ? file_actual_size : (buffer_size - 2);
    size_t bytes_read = 0;
    if (file_actual_size > 0) { bytes_read = file.readBytes(buffer, bytes_to_read); buffer[bytes_read] = '\0';  }
    else { Serial.println("INO: File is reported as empty by file.size()."); strncpy(buffer, "(File is empty)", buffer_size - 1); }
    file.close();
    if (bytes_read == 0 && file_actual_size > 0) { Serial.println("INO: Read 0 bytes, but file was not empty. Possible read issue."); }
    else if (bytes_read > 0) { Serial.printf("INO: Read %d bytes.\n", bytes_read); }
    if (file_actual_size > bytes_to_read && bytes_read > 0) { 
        Serial.println("INO: File content was truncated."); const char* truncated_msg = "\n...(truncated)";
        if (strlen(buffer) + strlen(truncated_msg) < buffer_size) { strcat(buffer, truncated_msg); }
    }
    return true; 
}

// --- Функции для работы с профилями на SD ---
int scanProfilesAndGetNextId(fs::FS &fs_ref, std::vector<String>& profiles_found_list) {
    profiles_found_list.clear();
    if (!sd_card_initialized) { Serial.println("scanProfiles: SD card not initialized."); return 1; }
    File root = fs_ref.open("/");
    if (!root) { Serial.println("scanProfiles: Failed to open root directory."); return 1; }
    if (!root.isDirectory()) { Serial.println("scanProfiles: Root is not a directory."); root.close(); return 1; }
    Serial.println("Scanning for profile_X.txt files..."); int max_id_found = 0; File entry = root.openNextFile();
    while (entry) {
        String entryName = entry.name(); if (entryName.startsWith("/")) { entryName = entryName.substring(1); }
        if (entryName.startsWith("profile_") && entryName.endsWith(".txt")) {
            Serial.print("  Found: "); Serial.println(entryName); profiles_found_list.push_back(entryName);
            String id_str = entryName.substring(8, entryName.length() - 4); int current_id = id_str.toInt();
            if (current_id > 0 && current_id > max_id_found) { max_id_found = current_id; }
        }
        entry.close(); entry = root.openNextFile();
    }
    root.close(); Serial.printf("Max profile ID found: %d. Next ID will be: %d\n", max_id_found, max_id_found + 1);
    return max_id_found + 1;
}

// --- Прототипы функций UI и обработчиков ---
static void build_main_app_screen(lv_obj_t* parent_screen);
static void build_profile_details_screen(lv_obj_t* parent_screen);
static void list_btn_delete_event_cb(lv_event_t * e); 
static void profile_list_event_handler(lv_event_t * e); 
static void profile_detail_start_event_cb(lv_event_t * e);
static void profile_detail_close_event_cb(lv_event_t * e); // ИЗМЕНЕНО
static void textarea_event_cb_main(lv_event_t * e);
static void keyboard_event_cb_main(lv_event_t * e);
static void save_button_event_cb_main(lv_event_t * e);
void updateDisplayedProfilesList_main(fs::FS &fs_ref, lv_obj_t* list_widget, const std::vector<String>* profiles_list_ptr = nullptr); 

// --- Реализация функций ---
static void list_btn_delete_event_cb(lv_event_t * e) {
    char* data_to_free = (char*)lv_event_get_user_data(e);
    if (data_to_free) { Serial.printf("Freeing user_data for list button: %s\n", data_to_free); free(data_to_free); }
}

void updateDisplayedProfilesList_main(fs::FS &fs_ref, lv_obj_t* list_widget, const std::vector<String>* profiles_list_ptr) {
    if (!list_widget) return;
    lv_obj_clean(list_widget); 
    std::vector<String> local_profiles_storage;
    const std::vector<String>* profiles_to_display;
    if (profiles_list_ptr) { profiles_to_display = profiles_list_ptr; }
    else {
        if (!sd_card_initialized) { lv_list_add_text(list_widget, "SD Card not ready."); return; }
        Serial.println("updateDisplayedProfilesList_main: Rescanning profiles from SD (default behavior)...");
        scanProfilesAndGetNextId(fs_ref, local_profiles_storage);
        profiles_to_display = &local_profiles_storage;
    }
    if (profiles_to_display->empty()) { lv_list_add_text(list_widget, "No saved profiles."); }
    else {
        for (const String& profile_name : *profiles_to_display) {
            lv_obj_t * btn = lv_list_add_btn(list_widget, LV_SYMBOL_FILE, profile_name.c_str());
            char* btn_filename_data = strdup(profile_name.c_str()); 
            if(btn_filename_data){
                 lv_obj_add_event_cb(btn, profile_list_event_handler, LV_EVENT_CLICKED, btn_filename_data);
                 lv_obj_add_event_cb(btn, list_btn_delete_event_cb, LV_EVENT_DELETE, btn_filename_data);
            } else { Serial.println("Failed to allocate memory for button user_data (profile name)"); }
        }
    }
}

bool initializeSDCard() { 
    Serial.println("Step 3: Initializing SD Card...");
    if (!ch422g) { Serial.println("Error: CH422G not available for SD card init."); return false; }
    SPI.end(); delay(10); SPI.setHwCs(false); SPI.begin(SD_CLK, SD_MISO, SD_MOSI);
    Serial.println("SPI for SD card initialized.");
    Serial.println("   Activating SD_CS (LOW) via expander BEFORE SD.begin(SD_SS=-1)...");
    ch422g->digitalWrite(SD_CS, LOW); delayMicroseconds(150);
    if (!SD.begin(SD_SS)) {
        Serial.println("ERROR: Card Mount Failed (SD.begin() returned false).");
        ch422g->digitalWrite(SD_CS, HIGH); return false;
    }
    Serial.println("SUCCESS: SD Card initialized. CS is now managed by SD.h library for operations.");
    uint8_t cardType = SD.cardType(); Serial.print("         Card Type: ");
    if (cardType == CARD_NONE) Serial.println("None");
    else if (cardType == CARD_MMC) Serial.println("MMC");
    else if (cardType == CARD_SD)  Serial.println("SDSC");
    else if (cardType == CARD_SDHC) Serial.println("SDHC");
    else Serial.println("UNKNOWN");
    if (cardType != CARD_NONE) {
        uint64_t cardSize = SD.cardSize() / (1024 * 1024);
        Serial.printf("         Card Size: %lluMB\n", cardSize);
        Serial.println("         Listing root directory (using your listDir from waveshare_sd_card.h)...");
        listDir(SD, "/", 0);
    }
    Serial.println("Step 3: SD Card initialized successfully.");
    return true;
 }

static void textarea_event_cb_main(lv_event_t * e) { 
    lv_event_code_t code = lv_event_get_code(e); lv_obj_t * ta = lv_event_get_target(e);
    if (code == LV_EVENT_FOCUSED) { if (kb_main_ui) { lv_keyboard_set_textarea(kb_main_ui, ta); lv_obj_clear_flag(kb_main_ui, LV_OBJ_FLAG_HIDDEN); lv_obj_align_to(kb_main_ui, ta_profile_input_main, LV_ALIGN_OUT_BOTTOM_MID, 0, 5); } }
}
static void keyboard_event_cb_main(lv_event_t * e) { 
    lv_event_code_t code = lv_event_get_code(e); lv_obj_t * kb_target = lv_event_get_target(e); 
    if (code == LV_EVENT_READY || code == LV_EVENT_CANCEL) {
        lv_obj_add_flag(kb_target, LV_OBJ_FLAG_HIDDEN); lv_obj_t* ta_associated = lv_keyboard_get_textarea(kb_target);
        if (ta_associated) { lv_obj_clear_state(ta_associated, LV_STATE_FOCUSED); lv_indev_reset(NULL, ta_associated); }
    }
}
static void profile_detail_start_event_cb(lv_event_t * e) {
    lv_event_code_t code = lv_event_get_code(e);
    if (code == LV_EVENT_CLICKED) {
        Serial.printf("--- START button clicked for profile: %s ---\n", active_profile_name_for_start);
        lvgl_port_lock(-1); 
        const char * mbox_btns[] = {"OK", ""};
        String msg_content = "Started profile: ";
        msg_content += active_profile_name_for_start;
        lv_obj_t* mbox = lv_msgbox_create(NULL, "Action", msg_content.c_str(), mbox_btns, true);
        lv_obj_center(mbox); 
        lvgl_port_unlock();
    }
}

// ИЗМЕНЕННАЯ ФУНКЦИЯ - АНИМАЦИЯ
static void profile_detail_close_event_cb(lv_event_t * e) {
    lv_event_code_t code = lv_event_get_code(e);
    if (code == LV_EVENT_CLICKED) {
        Serial.println("Close button on details screen clicked. Loading main screen.");
        if (screen_main_app) { 
            // Загружаем главный экран, он "въедет" справа, текущий (детали) "уедет" влево
            lv_scr_load_anim(screen_main_app, LV_SCR_LOAD_ANIM_MOVE_RIGHT, 300, 0, false); 
        }
    }
}

static void profile_list_event_handler(lv_event_t * e) {
    lv_event_code_t code = lv_event_get_code(e);
    if (code == LV_EVENT_CLICKED) {
        const char* stored_filename_c_str = (const char*)lv_event_get_user_data(e);
        if (!stored_filename_c_str) { Serial.println("Profile click: FATAL - No user_data!"); return; }
        strncpy(active_profile_name_for_start, stored_filename_c_str, sizeof(active_profile_name_for_start) - 1);
        active_profile_name_for_start[sizeof(active_profile_name_for_start) - 1] = '\0';
        Serial.printf("Clicked on profile: %s. Preparing detail screen.\n", active_profile_name_for_start);
        if (!sd_card_initialized) {
            Serial.println("Profile click: SD card not ready!");
            lvgl_port_lock(-1); const char * err_mbox_btns[] = {"OK", ""};
            lv_obj_t * mbox_err_sd = lv_msgbox_create(lv_scr_act(), "SD Error", "SD card not ready.", err_mbox_btns, true);
            lv_obj_center(mbox_err_sd); lvgl_port_unlock(); return;
        }
        String full_path_str = "/" + String(active_profile_name_for_start);
        bool read_ok = readFileContentToBuffer_ino(SD, full_path_str.c_str(), file_content_buffer, FILE_CONTENT_BUFFER_SIZE);
        
        lvgl_port_lock(-1);
        if (label_detail_profile_name && label_detail_profile_content) { 
            lv_label_set_text(label_detail_profile_name, active_profile_name_for_start);
            lv_label_set_text(label_detail_profile_content, file_content_buffer);
        } else { Serial.println("ERROR: Detail screen labels not ready or NULL!"); }
        
        if (screen_profile_details) { 
            Serial.println("Loading profile_details_screen..."); 
            // Экран деталей "въезжает" слева, текущий (главный) "уезжает" вправо
            lv_scr_load_anim(screen_profile_details, LV_SCR_LOAD_ANIM_MOVE_LEFT, 300, 0, false); 
        }
        else { Serial.println("ERROR: screen_profile_details is NULL!"); }
        lvgl_port_unlock();
    }
}
static void save_button_event_cb_main(lv_event_t * e) {
    lv_event_code_t code = lv_event_get_code(e);
    if (code == LV_EVENT_CLICKED) {
        const char* text_to_save = lv_textarea_get_text(ta_profile_input_main);
        if (strlen(text_to_save) == 0) { lv_label_set_text(label_status_msg_main, "Error: Input is empty!"); return; }
        if (!sd_card_initialized) { lv_label_set_text(label_status_msg_main, "Error: SD Card not ready!"); return; }
        String filename = "/profile_" + String(current_profile_next_id) + ".txt";
        Serial.printf("Attempting to save to %s\n", filename.c_str());
        writeFile(SD, filename.c_str(), text_to_save); 
        bool save_verified = false; File checkFile = SD.open(filename.c_str(), FILE_READ);
        if (checkFile) {
            if (checkFile.size() > 0) { save_verified = true; Serial.println("Verification: File exists and is not empty."); }
            else { Serial.println("Verification: File exists but is EMPTY. Save likely failed."); }
            checkFile.close();
        } else { Serial.println("Verification: File does not exist after write attempt. Save failed."); }
        char msg_buffer[64]; lvgl_port_lock(-1);
        if (save_verified) {
            sprintf(msg_buffer, "Profile %d saved!", current_profile_next_id);
            lv_label_set_text(label_status_msg_main, msg_buffer);
            Serial.printf("Profile %d saved and verified as %s.\n", current_profile_next_id, filename.c_str());
            lv_textarea_set_text(ta_profile_input_main, ""); current_profile_next_id++;
            updateDisplayedProfilesList_main(SD, list_profiles_main); 
        } else {
            sprintf(msg_buffer, "Error saving profile %d!", current_profile_next_id);
            lv_label_set_text(label_status_msg_main, msg_buffer);
            Serial.printf("Failed to save or verify profile %d as %s.\n", current_profile_next_id, filename.c_str());
        }
        lvgl_port_unlock();
    }
}

// ИЗМЕНЕННАЯ ФУНКЦИЯ - FLEX_GROW для списка
void build_main_app_screen(lv_obj_t* parent_screen) {
    Serial.println("Building main_app_screen UI...");
    lv_obj_set_flex_flow(parent_screen, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(parent_screen, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_START);
    lv_obj_set_style_pad_all(parent_screen, 5, 0);
    lv_obj_set_style_pad_gap(parent_screen, 8, 0); 
    lv_obj_set_scrollbar_mode(parent_screen, LV_SCROLLBAR_MODE_OFF);

    lv_obj_t* list_header_label = lv_label_create(parent_screen);
    lv_label_set_text(list_header_label, "Saved Profiles (click to view):");
    lv_obj_set_width(list_header_label, LV_PCT(95));

    list_profiles_main = lv_list_create(parent_screen);
    lv_obj_set_width(list_profiles_main, LV_PCT(95));
    lv_obj_set_flex_grow(list_profiles_main, 1); // <--- ИЗМЕНЕНИЕ: список будет расти
    lv_obj_set_scrollbar_mode(list_profiles_main, LV_SCROLLBAR_MODE_AUTO); // Скролл для самого списка


    ta_profile_input_main = lv_textarea_create(parent_screen);
    lv_textarea_set_one_line(ta_profile_input_main, false);
    lv_textarea_set_placeholder_text(ta_profile_input_main, "Enter new profile data...");
    lv_obj_set_width(ta_profile_input_main, LV_PCT(95));
    lv_obj_set_height(ta_profile_input_main, 60); 

    lv_obj_add_event_cb(ta_profile_input_main, textarea_event_cb_main, LV_EVENT_ALL, NULL);

    lv_obj_t* btn_save = lv_btn_create(parent_screen);
    lv_obj_add_event_cb(btn_save, save_button_event_cb_main, LV_EVENT_CLICKED, NULL);
    lv_obj_set_width(btn_save, LV_PCT(50));
    lv_obj_t * label_btn_text = lv_label_create(btn_save);
    lv_label_set_text(label_btn_text, "Save Profile");
    lv_obj_center(label_btn_text);

    label_status_msg_main = lv_label_create(parent_screen);
    lv_label_set_text(label_status_msg_main, "Ready.");
    lv_obj_set_width(label_status_msg_main, LV_PCT(95));
    lv_obj_set_style_text_align(label_status_msg_main, LV_TEXT_ALIGN_CENTER, 0);

    kb_main_ui = lv_keyboard_create(parent_screen); 
    lv_obj_add_flag(kb_main_ui, LV_OBJ_FLAG_HIDDEN);
    lv_obj_set_size(kb_main_ui, LV_PCT(100), LV_PCT(45));
    lv_obj_align(kb_main_ui, LV_ALIGN_BOTTOM_MID, 0, 0);
    lv_obj_add_event_cb(kb_main_ui, keyboard_event_cb_main, LV_EVENT_ALL, NULL);
}
void build_profile_details_screen(lv_obj_t* parent_screen) {
    Serial.println("Building profile_details_screen UI...");
    lv_obj_set_flex_flow(parent_screen, LV_FLEX_FLOW_COLUMN);
    lv_obj_set_flex_align(parent_screen, LV_FLEX_ALIGN_START, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_START);
    lv_obj_set_style_pad_all(parent_screen, 15, 0);
    lv_obj_set_style_pad_gap(parent_screen, 15, 0);
    lv_obj_set_scrollbar_mode(parent_screen, LV_SCROLLBAR_MODE_OFF);

    label_detail_profile_name = lv_label_create(parent_screen);
    lv_label_set_text(label_detail_profile_name, "Profile: -----"); 
    // lv_obj_set_style_text_font(label_detail_profile_name, &lv_font_montserrat_16, 0);
    lv_obj_set_width(label_detail_profile_name, lv_pct(100));
    lv_obj_set_style_text_align(label_detail_profile_name, LV_TEXT_ALIGN_CENTER, 0);

    lv_obj_t* content_container = lv_obj_create(parent_screen);
    lv_obj_remove_style_all(content_container); 
    lv_obj_set_width(content_container, lv_pct(100)); 
    lv_obj_set_flex_grow(content_container, 1); 
    lv_obj_set_style_border_width(content_container, 1, 0);
    lv_obj_set_style_border_color(content_container, lv_palette_main(LV_PALETTE_GREY), 0);
    lv_obj_set_style_pad_all(content_container, 5, 0);
    lv_obj_set_scrollbar_mode(content_container, LV_SCROLLBAR_MODE_AUTO);

    label_detail_profile_content = lv_label_create(content_container);
    lv_label_set_long_mode(label_detail_profile_content, LV_LABEL_LONG_WRAP);
    lv_label_set_text(label_detail_profile_content, "Loading content..."); 
    lv_obj_set_width(label_detail_profile_content, lv_pct(100)); 

    lv_obj_t* btn_container = lv_obj_create(parent_screen);
    lv_obj_remove_style_all(btn_container);
    lv_obj_set_width(btn_container, lv_pct(100));
    lv_obj_set_height(btn_container, LV_SIZE_CONTENT);
    lv_obj_set_flex_flow(btn_container, LV_FLEX_FLOW_ROW);
    lv_obj_set_flex_align(btn_container, LV_FLEX_ALIGN_SPACE_EVENLY, LV_FLEX_ALIGN_CENTER, LV_FLEX_ALIGN_CENTER); 
    lv_obj_set_style_pad_top(btn_container, 10, 0);

    lv_obj_t* btn_start = lv_btn_create(btn_container); 
    lv_obj_add_event_cb(btn_start, profile_detail_start_event_cb, LV_EVENT_CLICKED, NULL);
    lv_obj_set_size(btn_start, 120, 50);
    lv_obj_t * label_start_txt = lv_label_create(btn_start);
    lv_label_set_text(label_start_txt, "Start");
    lv_obj_center(label_start_txt);

    lv_obj_t* btn_close = lv_btn_create(btn_container);
    lv_obj_add_event_cb(btn_close, profile_detail_close_event_cb, LV_EVENT_CLICKED, NULL);
    lv_obj_set_size(btn_close, 120, 50);
    lv_obj_t * label_close_txt = lv_label_create(btn_close);
    lv_label_set_text(label_close_txt, "Close");
    lv_obj_center(label_close_txt);
}

void setup() {
    Serial.begin(115200);
    Serial.println("\n\n--- System Setup Starting ---");
    Serial.println("Step 1: Initializing board object...");
    board = new Board();
    if (!board) { handleFatalError("Failed to create Board object!"); } 
    board->init();
    Serial.println("Board object init() called.");
    esp_expander::Base* baseExpander = board->getExpander();
    if (!baseExpander) { handleFatalError("Failed to get expander from board after init!"); }
    ch422g = static_cast<esp_expander::CH422G*>(baseExpander);
    if (!ch422g) { handleFatalError("Wrong expander type or failed to cast!"); }
    Serial.println("Expander CH422G object obtained.");
#if defined(LVGL_PORT_AVOID_TEARING_MODE) && LVGL_PORT_AVOID_TEARING_MODE
    Serial.println("AVOID_TEARING_MODE is enabled, configuring frame/bounce buffers...");
    auto lcd = board->getLCD();
    if (lcd) {
        #ifndef LVGL_PORT_DISP_BUFFER_NUM
            #define LVGL_PORT_DISP_BUFFER_NUM 2
            Serial.println("Warning: LVGL_PORT_DISP_BUFFER_NUM was not defined, defaulting to 2 for tearing avoidance.");
        #endif
        lcd->configFrameBufferNumber(LVGL_PORT_DISP_BUFFER_NUM);
        Serial.printf("  Frame buffer number configured to: %d\n", (int)LVGL_PORT_DISP_BUFFER_NUM);
    #if ESP_PANEL_DRIVERS_BUS_ENABLE_RGB && CONFIG_IDF_TARGET_ESP32S3
        auto lcd_bus = lcd->getBus();
        if (lcd_bus && lcd_bus->getBasicAttributes().type == ESP_PANEL_BUS_TYPE_RGB) {
            int bounce_buffer_size_px = lcd->getFrameWidth() * 10;
            static_cast<BusRGB *>(lcd_bus)->configRGB_BounceBufferSize(bounce_buffer_size_px);
            Serial.printf("  RGB Bounce buffer size configured for up to %d pixels wide lines\n", bounce_buffer_size_px);
        } else if (lcd_bus && lcd_bus->getBasicAttributes().type != ESP_PANEL_BUS_TYPE_RGB) {
             Serial.println("  LCD bus is not RGB type, skipping bounce buffer config.");
        } else if (!lcd_bus) {
            Serial.println("  Failed to get LCD bus, skipping bounce buffer config.");
        }
    #endif
    } else { Serial.println("Error: Failed to get LCD from board for buffer configuration!"); }
#else
    Serial.println("AVOID_TEARING_MODE is not enabled or macro not defined.");
#endif
    Serial.println("Attempting board->begin()...");
    if (!board->begin()) { handleFatalError("Board->begin() failed!"); }
    Serial.println("Board->begin() success.");
    Serial.println("Step 2: Configuring Expander Pins...");
    if (!ch422g) { handleFatalError("CH422G not available after board->begin() for pin config."); }
    ch422g->multiPinMode(TP_RST | LCD_BL | LCD_RST, OUTPUT);
    ch422g->multiDigitalWrite(TP_RST | LCD_RST, HIGH);
    ch422g->digitalWrite(LCD_BL, HIGH);
    ch422g->multiPinMode(SD_CS | USB_SEL, OUTPUT);
    ch422g->digitalWrite(USB_SEL, LOW);
    ch422g->digitalWrite(SD_CS, HIGH);
    Serial.println("Step 2: Expander Pins configured."); delay(100);
    sd_card_initialized = initializeSDCard(); delay(100);
    Serial.println("Step 4: Initializing LVGL port...");
    if (!lvgl_port_init(board->getLCD(), board->getTouch())) {
         handleFatalError("lvgl_port_init failed! Check LVGL buffer settings/PSRAM & menuconfig.");
    }
    Serial.println("Step 4: LVGL port initialized.");
    Serial.println("Step 5: Creating LVGL Screens and UI...");
    lvgl_port_lock(-1);
    screen_main_app = lv_obj_create(NULL); 
    screen_profile_details = lv_obj_create(NULL);
    build_main_app_screen(screen_main_app);
    build_profile_details_screen(screen_profile_details);
    lv_scr_load(screen_main_app);
    Serial.println("Main app screen loaded.");
    if (sd_card_initialized) {
        Serial.println("SD card ready. Populating UI with profile list...");
        std::vector<String> initial_profiles_list;
        current_profile_next_id = scanProfilesAndGetNextId(SD, initial_profiles_list);
        if (list_profiles_main) { 
            updateDisplayedProfilesList_main(SD, list_profiles_main, &initial_profiles_list); 
        }
    } else {
        Serial.println("SD card not initialized. UI will reflect this.");
        current_profile_next_id = 1;
        if (list_profiles_main) { lv_list_add_text(list_profiles_main, "SD Card not detected."); }
        if (label_status_msg_main) lv_label_set_text(label_status_msg_main, "SD Card not detected!");
    }
    lvgl_port_unlock();
    Serial.println("Step 5: LVGL UI (multi-screen) created and populated.");
    Serial.println("--- System Setup Complete ---");
}

void loop() {
    // lv_timer_handler(); // ЗАКОММЕНТИРОВАНО
    delay(10);
}